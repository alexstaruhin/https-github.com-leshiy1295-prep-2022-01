#ifndef UTILS_H
#define UTILS_H


size_t timer_from(unsigned char from);
// TODO: Implement `power of` function
// int custom_pow(int base, int power);

#endif //UTILS_H

